import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { TestService } from './test.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  message:string;
  tests :any[];
  constructor(private apiservice:ApiService, private testservice:TestService) { }

  ngOnInit(): void {
    this.tests=this.testservice.getTests();
    this.message = this.apiservice.getTestDetail('Test Component');
    //this. getTestAll();
  }


  //Only Testing Purpose
  public getTestAll()
  {
    try{
      let url = 'https://rxa2kktrwh.execute-api.us-east-1.amazonaws.com/dev/pets';
      this.apiservice.getAll(url).subscribe(response=>
        {
          console.log('byeeeeeeeee');
        });
    }catch(error)
    {
      console.log('errrrrrrrrrrrrrrrrrr');
    }
  }

}
