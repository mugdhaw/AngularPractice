import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TestRoutingModule } from './test-routing.module';
import { TestComponent } from './test.component';
import { TestService } from './test.service';
import { TestDetailComponent } from './test-detail/test-detail.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [TestComponent, TestDetailComponent],
  imports: [
    CommonModule,
    TestRoutingModule,
    HttpClientModule
  ],
  providers:[{provide:TestService}]
})
export class TestModule { }
