import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-test-detail',
  templateUrl: './test-detail.component.html',
  styleUrls: ['./test-detail.component.css']
})
export class TestDetailComponent implements OnInit {
@Input() testData:any[];
  constructor() { }

  ngOnInit(): void {
    //console.log('Test-Detail: ');
    //console.log(this.testData);
  }
  

}
