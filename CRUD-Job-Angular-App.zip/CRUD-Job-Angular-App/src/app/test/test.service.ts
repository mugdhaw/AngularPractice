import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor() { }

  getTests() {
    return TESTS;
  }
}

const TESTS = [
  {
    id: 1,
    name: 'Test 1',
    testtype: 'OPM',
    testsubtype: 'A->B',
    status: 'Complete',
  },
  {
    id: 2,
    name: 'Test 2',
    testtype: 'OLX',
    testsubtype: 'A->B',
    status: 'Not Done',
  },
  {
    id: 3,
    name: 'Test 3',
    testtype: 'FIP',
    testsubtype: 'FIP',
    status: 'Done',
  },
  {
    id: 4,
    name: 'Test 4',
    testtype: 'OLTS',
    testsubtype: 'B->A',
    status: 'Complete',
  }
];
