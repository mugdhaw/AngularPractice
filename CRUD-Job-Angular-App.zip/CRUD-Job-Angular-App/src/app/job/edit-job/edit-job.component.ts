import { Component, OnInit } from '@angular/core';
import {Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { JobService } from '../job.service';

@Component({
  selector: 'app-edit-job',
  templateUrl: './edit-job.component.html',
  styleUrls: ['./edit-job.component.css']
})
export class EditJobComponent implements OnInit {
  angForm: FormGroup;

  constructor(private router : Router,private fb: FormBuilder, private jobservice:JobService) { }

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {  
    this.angForm = this.fb.group({  
      JobName: 'New job 1',  
      CompanyName: 'Googlr',
      CustomerName:'Google',
      OperatorA: '',
      OperatorB:  '',
      LocationA:  'India',
      LocationB:  'USA',
      DueDate:  '2020/06/10',
    });  
  }

  updateJobs(formvalue)
  { 
    console.log(formvalue.value);
  }

  cancleCreteJob()
  {
    this.router.navigate(['job']);
  }

}
