import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs'
import{ IJob} from './ijob'


@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor() { }

  getJobs() {
    return JOBS;
  }
}
const JOBS:IJob[] = [
  {
    id: 1,
    name: 'Exfo job 1',
    company: 'Reliance',
    customer: 'Job',
    operatorA: 'jio@test.com',
    operatorB: 'jio@test.com',
    locationA: 'Pune',
    locationB: 'Mumbai',
    dueDate: '2020/06/30',
  },
  {
    id: 2,
    name: 'Test Job',
    company: 'Google',
    customer: 'Google',
    operatorA: 'google@test.com',
    operatorB: 'google@test.com',
    locationA: 'Pune',
    locationB: 'Mumbai',
    dueDate:'2020/06/27',
  },
  {
    id: 3,
    name: 'Demo Job',
    company: 'Microsoft',
    customer: 'Microsoft',
    operatorA: 'microsoft@test.com',
    operatorB: 'microsoft@test.com',
    locationA: 'Pune',
    locationB: 'Mumbai',
    dueDate: '2020/06/25',
  },
  {
    id: 4,
    name: 'Job 1234',
    company: 'Vodafone',
    customer: 'Vodafone',
    operatorA: 'vodafone@test.com',
    operatorB: 'vodafone@test.com',
    locationA: 'Pune',
    locationB: 'Mumbai',
    dueDate:'2020/06/10',
  },
  {
    id: 5,
    name: 'New Job 1',
    company: 'Airtel',
    customer: 'Airtel',
    operatorA: 'airtel@test.com',
    operatorB: 'airtel@test.com',
    locationA: 'Pune',
    locationB: 'Mumbai',
    dueDate: '2020/06/20',
  }
]
