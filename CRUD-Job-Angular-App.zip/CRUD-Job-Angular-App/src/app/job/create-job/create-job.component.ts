import { Component, OnInit } from '@angular/core';
import {Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { JobService } from '../job.service';

@Component({
  selector: 'app-create-job',
  templateUrl: './create-job.component.html',
  styleUrls: ['./create-job.component.css']
})
export class CreateJobComponent implements OnInit {
  angForm: FormGroup;

  constructor(private router : Router,private fb: FormBuilder, private jobservice:JobService) { 
    this.createForm();
  }

  ngOnInit(): void {
  }
  
  createForm() {  
    this.angForm = this.fb.group({  
      JobName: ['', Validators.required ],  
      CompanyName: ['', Validators.required ],
      CustomerName: ['' ],
      OperatorA:  ['' ],
      OperatorB:  ['' ],
      LocationA:  ['' ],
      LocationB:  ['' ],
      DueDate:  ['' ],
    });  
  }

  addJobs(formvalue)
  {
    console.log(formvalue.value);
  }

  cancleCreteJob()
  {
    this.router.navigate(['job']);
  }

}
