import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JobRoutingModule } from './job-routing.module';
import { JobComponent } from './job.component';
import { JobService } from './job.service';
import { CreateJobComponent } from './create-job/create-job.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EditJobComponent } from './edit-job/edit-job.component'; 

@NgModule({
  declarations: [JobComponent, CreateJobComponent, EditJobComponent],
  imports: [
    CommonModule,
    JobRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers:[{provide:JobService}]
})
export class JobModule { }
