import { Component, OnInit } from '@angular/core';
import { JobService } from './job.service';
import{ IJob} from './ijob'
import { ApiService } from '../api.service';

@Component({
  selector: 'app-job',
  templateUrl: './job.component.html',
  styleUrls: ['./job.component.css']
})
export class JobComponent implements OnInit {
  message:string;
  filterJobs:IJob[];
  jobs:IJob[];
  showJobNotFound:boolean;
  constructor(private jobservice:JobService, private apiservice:ApiService) { }

  ngOnInit(): void {
    this.jobs=this.jobservice.getJobs();
    this.filterJobs = this.jobs;
    this.message = this.apiservice.getTestDetail('Job Component');
    //console.log(this.jobs);
  }

  public deleteJob(id) {
    console.log(id);
  }

//Search Data
  public searchJob(searchInput) {
    //Empty string
   if(searchInput=='') {
    this.filterJobs = this.jobs;
    this.showJobNotFound=false;
   }
   //Filter data in array
    this.filterJobs = Object.assign([], this.filterJobs).filter(
      item => item.name.toLowerCase().indexOf(searchInput.toLowerCase()) > -1,
   )
   //Not Found Data
   if( this.filterJobs.length===0) {
     this.showJobNotFound=true;
   }
  }
  
// Check Sorted by Type
  public sortJob(sortInput) {
    if(sortInput=='name') {
       this.sortedByName(sortInput);
    }else {
      this.sortedByDuedate();
    }
  }

  // Sorted by Date
  public sortedByDuedate() {
    return this.filterJobs.sort((a, b) => {
      return <any>new Date(a.dueDate) - <any>new Date(b.dueDate);
    });
  }

  // Sorted by name
  public sortedByName(sortInput) {
    this.filterJobs.sort(this.dynamicSort(sortInput));
    return this.filterJobs;
  }
  
  //Compare name for sorted data
  public dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
 }

  //Only Testing Purpose
  public getTestAll()
  {
    try{
      let url = 'https://rxa2kktrwh.execute-api.us-east-1.amazonaws.com/dev/pets';
      this.apiservice.getAll(url).subscribe(response=>
        {
          console.log('byeeeeeeeee');
        });
    }catch(error)
    {
      console.log('errrrrrrrrrrrrrrrrrr');
    }
  }
}
