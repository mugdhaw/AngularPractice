export interface IJob {
    id: number
    name: string
    company: string
    customer: string
    operatorA: string
    operatorB: string
    locationA: string
    locationB: string
    dueDate: string
}
