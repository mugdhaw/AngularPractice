import { Injectable } from '@angular/core';
import { HttpClient,HttpHandler,HttpEvent, HttpInterceptor, HttpRequest,HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private static count = 0;
  constructor(private http: HttpClient) {
    ApiService.count = ApiService.count + 1;
    console.log('Api Service Object - ' + ApiService.count);
   }

  public getTestDetail(name:string) 
  {
    return "New App Details  :: " + name;
  }

  //Get All Data
  public getAll<T>(url:any): Observable<T>
  {
    return this.http.get<T>(url);
  }

  //Add New Data
  public add<T>(url,itemName: any[]): Observable<T>
  {
    return this.http.post<T>(url, itemName);
  }

  //Update Data
  public update<T>(url,id: any, itemToUpdate: any): Observable<T>
  {
    return this.http.put<T>(url + id , JSON.stringify(itemToUpdate));
  }

  //Delete Data
  public delete<T>(url,id: string): Observable<T>
  {
    return this.http.delete<T>(url + id );
  }
}


@Injectable()
export class TokenInterceptor implements HttpInterceptor 
{
  intercept (req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const authReq = req.clone({
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Access-Control-Allow-Origin': '*',
      })
    });
    return next.handle(authReq);
  }
}

